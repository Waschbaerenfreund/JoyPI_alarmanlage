#include <unistd.h>
#include <iostream>
#include <string>

#include "MCP3008.h"

using namespace std;

void delay(int ms){
  usleep(ms*1000);
}

int main(){
  
  MCP3008 adc;
  adc.connect();

  unsigned short v[8];

  while(true){
    for(int i = 0; i<8; i++){
      v[i] = adc.read(i); //read mcp300x channel 0 to 7
      cout << v[i] << (i<7?" / ":"");  
    }
    cout << endl;
    delay(1000);
  }

  return 0;
}
